from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "supersecretkey"  # palitan mo ito

# --- DB INIT ---
def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    # Users table
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        middle_name TEXT,
        barangay_id TEXT UNIQUE,
        email TEXT UNIQUE,
        password TEXT NOT NULL,
        address TEXT,
        role TEXT DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    # Bookings table
    c.execute("""CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        ticket_number TEXT UNIQUE,
        event_type TEXT,
        status TEXT DEFAULT 'Pending',
        note TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")

    # Insert default admin if not exists
    c.execute("SELECT * FROM users WHERE role='admin'")
    if not c.fetchone():
        c.execute("""INSERT INTO users (first_name,last_name,email,password,role)
                     VALUES (?,?,?,?,?)""",
                  ("Admin","User","admin@baritan.ph",
                   generate_password_hash("admin123"), "admin"))
    conn.commit()
    conn.close()




# --- ROUTES ---
@app.route("/")
def home():
    return render_template("index.html")






@app.route("/signup", methods=["GET","POST"])
def signup():
    if request.method == "POST":
        fname = request.form["first_name"]
        lname = request.form["last_name"]
        mname = request.form.get("middle_name")
        bid = request.form["barangay_id"]
        email = request.form["email"]
        password = request.form["password"]
        confirm = request.form["confirm_password"]
        address = request.form["address"]

        if password != confirm:
            flash("Passwords do not match!", "error")
            return redirect(url_for("signup"))

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        try:
            c.execute("""INSERT INTO users 
                (first_name,last_name,middle_name,barangay_id,email,password,address)
                VALUES (?,?,?,?,?,?,?)""",
                (fname,lname,mname,bid,email,generate_password_hash(password),address))
            conn.commit()
            flash("Account created! Please sign in.", "success")
            return redirect(url_for("signin"))
        except sqlite3.IntegrityError:
            flash("Email or Barangay ID already exists!", "error")
            return redirect(url_for("signup"))
        finally:
            conn.close()

    return render_template("signup.html")

@app.route("/signin", methods=["GET","POST"])
def signin():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email=?", (email,))
        user = c.fetchone()
        conn.close()

        if user and check_password_hash(user[6], password):
            session["user_id"] = user[0]
            session["role"] = user[8]
            flash("Welcome back!", "success")

            if user[8] == "admin":
                return redirect(url_for("admin_portal"))
            else:
                return redirect(url_for("booking"))
                
        else:
            flash("Invalid email or password!", "error")
            return redirect(url_for("signin"))
            

    return render_template("signin.html")

@app.route("/booking")
def booking():
    if "user_id" not in session:
        flash("Please login first!", "error")
        return redirect(url_for("signin"))
    return render_template("booking.html")



@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email=? AND role='admin'", (email,))
        admin = c.fetchone()
        conn.close()

        if admin and check_password_hash(admin[6], password):
            session["user_id"] = admin[0]
            session["role"] = "admin"
            # flash("Welcome Admin!", "success")
            return redirect(url_for("admin_portal"))
        else:
            flash("Invalid admin credentials!", "error")
            return redirect(url_for("admin_login"))

    return render_template("admin_login.html")

# @app.route("/admin_login", methods=["GET", "POST"])
# def admin_login():
#     if request.method == "POST":
#         email = request.form["email"]
#         password = request.form["password"]

#         try:
#             conn = sqlite3.connect("database.db")
#             c = conn.cursor()
#             c.execute("SELECT * FROM users WHERE email=? AND role='admin'", (email,))
#             admin = c.fetchone()
#         except sqlite3.Error as e:
#             flash("Database error occurred!", "error")
#             return redirect(url_for("admin_login"))
#         finally:
#             conn.close()

#         if admin and check_password_hash(admin[6], password):
#             session["user_id"] = admin[0]
#             session["role"] = "admin"
#             return redirect(url_for("admin_portal"))
#         else:
#             flash("Invalid admin credentials!", "error")
#             return redirect(url_for("admin_login"))

#     return render_template("admin_login.html")

@app.route("/admin_portal")
def admin_portal():
    if session.get("role") != "admin":
        flash("Admins only!", "error")
        return redirect(url_for("signin"))

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT * FROM bookings")
    bookings = c.fetchall()
    conn.close()

    return render_template("admin_portal.html", bookings=bookings)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out!", "success")
    return redirect(url_for("signin"))

@app.route("/signout", methods=["POST"])
def signout():
    session.pop("user", None)  # remove user session
    return redirect(url_for("admin_login")) 

# --- RUN ---
if __name__ == "__main__":
    init_db()
    app.run(debug=True)





















# @app.route("/admin_login", methods=["GET","POST"])
# def admin_login():
#     if request.method == "POST":
#         email = request.form["username"]  # adjust kung username
#         password = request.form["password"]

#         conn = sqlite3.connect("database.db")
#         c = conn.cursor()
#         c.execute("SELECT * FROM users WHERE email=? AND role='admin'", (email,))
#         admin = c.fetchone()
#         conn.close()

#         if admin and check_password_hash(admin[6], password):
#             session["user_id"] = admin[0]
#             session["role"] = "admin"
#             return redirect(url_for("admin_portal"))
#         else:
#             flash("Invalid admin credentials!", "error")
#             return redirect(url_for("admin_login"))

#     return render_template("admin_login.html")